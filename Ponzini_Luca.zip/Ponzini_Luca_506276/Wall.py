import pygame
from castles_war_constants import *

# Define walls class
class Wall(pygame.sprite.Sprite):
    def __init__(self, player):
        super().__init__()
        if player == 1:
            self.image = pygame.image.load('player1/building/wall.png')
            self.rect = self.image.get_rect(midbottom = (140 + MINE_POS, 250 - GROUND_HEIGHT))
        elif player == 2:
            self.image = pygame.image.load('player2/building/wall.png')
            self.rect = self.image.get_rect(midbottom=(860 - MINE_POS, 250 - GROUND_HEIGHT))




