import pygame
from castles_war_constants import *

# Swordsman collisions 
def swordsmen_collision(swordsmen1_army, swordsmen2_army, walls1_building, walls2_building, archers1_army, archers2_army):

    for swordman in swordsmen1_army:
        if pygame.sprite.spritecollideany(swordman, swordsmen2_army): swordman.attacking = True
        if pygame.sprite.spritecollideany(swordman, walls2_building): swordman.attacking_tower = True
        else: swordman.attacking = False
        if swordman.attacking == True:
            for swordman in swordsmen2_army:
                if swordman.attacking == True: swordman.health -= SWORD_HIT

    for swordman in swordsmen2_army:
        if pygame.sprite.spritecollideany(swordman, swordsmen1_army): swordman.attacking = True
        if pygame.sprite.spritecollideany(swordman, walls1_building): swordman.attacking_tower = True
        else: swordman.attacking = False

        if swordman.attacking == True:
            for swordman in swordsmen1_army:
                if swordman.attacking == True: swordman.health -= SWORD_HIT
